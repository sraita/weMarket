var require = meteorInstall({"lib":{"06_router_server.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/06_router_server.js                                                                                            //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 1
  // 微信登录callback                                                                                                     // 2
  Router.route('/oauth/wechat', {                                                                                     // 3
    where: 'server'                                                                                                   // 3
  }).get(function () {                                                                                                // 3
    var appid = 'wxf5fdcd705a634bc9';                                                                                 // 4
    var app_secret = 'e1d302d0e7f91b7d989eb42ddbc2ab5e';                                                              // 5
    var userInfo = {};                                                                                                // 6
    var code = this.request.query.code;                                                                               // 8
    var token_url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' + appid + '&secret=' + app_secret + '&code=' + code + '&grant_type=authorization_code';
    console.log('code = ', code);                                                                                     // 12
    var self = this;                                                                                                  // 13
    HTTP.get(token_url, function (error, result) {                                                                    // 14
      if (!error) {                                                                                                   // 15
        var resp = JSON.parse(result.content);                                                                        // 16
        console.log(JSON.stringify(resp));                                                                            // 17
        var access_token = resp.access_token;                                                                         // 18
        var openId = resp.openid;                                                                                     // 19
        var user_info_url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' + access_token + '&openid=' + openId + '&lang=zh_CN';
        console.log(user_info_url);                                                                                   // 22
        HTTP.get(user_info_url, function (error, result) {                                                            // 24
          if (!error) {                                                                                               // 25
            var resp = result.content;                                                                                // 26
            console.log(resp);                                                                                        // 27
            return self.response.end(JSON.stringify(resp));                                                           // 28
          } else {                                                                                                    // 29
            return self.response.end('result: error where get userinfo');                                             // 30
          }                                                                                                           // 31
        });                                                                                                           // 32
      } else {                                                                                                        // 33
        return self.response.end('result: error where get access_token');                                             // 34
      }                                                                                                               // 35
    });                                                                                                               // 36
  });                                                                                                                 // 38
  Router.route('restapi/qr-company', {                                                                                // 40
    where: 'server'                                                                                                   // 40
  }).get(function () {                                                                                                // 40
    var companyId = this.params.query.id;                                                                             // 42
    Router.route('/reporter/:_id', function (req, res, next) {                                                        // 42
      var data = {                                                                                                    // 43
        companyId: this.params._id                                                                                    // 44
      };                                                                                                              // 43
                                                                                                                      //
      if (Company.find({                                                                                              // 46
        _id: this.params._id                                                                                          // 46
      }).count() === 0) {                                                                                             // 46
        res.writeHead(404, {                                                                                          // 47
          'Content-Type': 'text/html'                                                                                 // 48
        });                                                                                                           // 47
        res.end('<head>\
          <meta charset="utf-8">\
          <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">\
          <title>没有查询到相关信息</title>\
        </head>\
        <body><h1 style="text-align:center">没有查询到相关信息</h1><hr/></body>', data);                                       //
      }                                                                                                               // 56
                                                                                                                      //
      var reporterHTML = SSR.render('dailyRepoter', data);                                                            // 57
      res.writeHead(200, {                                                                                            // 58
        'Content-Type': 'text/html'                                                                                   // 59
      });                                                                                                             // 58
      res.end(reporterHTML, data);                                                                                    // 61
    }, {                                                                                                              // 62
      where: 'server'                                                                                                 // 62
    });                                                                                                               // 62
  });                                                                                                                 // 63
}                                                                                                                     // 64
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"1_startup.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/1_startup.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// Meteor.absoluteUrl.defaultOptions.rootUrl = "http://192.168.0.108:3000"                                            // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"2_collections.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/2_collections.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
//  数据库定义                                                                                                             // 1
function buildRegExp(searchText) {                                                                                    // 2
  var words = searchText.trim().split(/[ \-\:]+/);                                                                    // 3
                                                                                                                      //
  var exps = _.map(words, function (word) {                                                                           // 4
    return "(?=.*" + word + ")";                                                                                      // 5
  });                                                                                                                 // 6
                                                                                                                      //
  var fullExp = exps.join('') + ".+";                                                                                 // 7
  return new RegExp(fullExp, "i");                                                                                    // 8
} // 产品分类表                                                                                                            // 9
                                                                                                                      //
                                                                                                                      //
Categories = new Mongo.Collection('categories'); // 产品表                                                               // 11
                                                                                                                      //
Products = new Mongo.Collection('products'); // 订单表                                                                   // 13
                                                                                                                      //
Orders = new Mongo.Collection('orders'); // 用户购物车                                                                     // 15
                                                                                                                      //
Shopping = new Mongo.Collection('shopping'); // 微信token                                                               // 17
                                                                                                                      //
AccessToken = new Mongo.Collection('access_token'); // 用户商品寄送地址信息                                                     // 20
                                                                                                                      //
Contact = new Mongo.Collection('contact');                                                                            // 23
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 25
  // search products                                                                                                  // 26
  SearchSource.defineSource('products', function (searchText, options) {                                              // 27
    var options = {                                                                                                   // 28
      sort: {                                                                                                         // 28
        createdAt: -1                                                                                                 // 28
      }                                                                                                               // 28
    };                                                                                                                // 28
                                                                                                                      //
    if (searchText) {                                                                                                 // 30
      var regExp = buildRegExp(searchText);                                                                           // 31
      var selector = {                                                                                                // 32
        name: regExp                                                                                                  // 32
      };                                                                                                              // 32
      return Products.find(selector, options).fetch();                                                                // 33
    } else {                                                                                                          // 34
      return Products.find({}, options).fetch();                                                                      // 35
    }                                                                                                                 // 36
  });                                                                                                                 // 37
}                                                                                                                     // 38
                                                                                                                      //
if (Meteor.isClient) {                                                                                                // 40
  ProductsSearch = new SearchSource('products', ['name'], {                                                           // 41
    keepHistory: 1000 * 60 * 5,                                                                                       // 42
    localSearch: true                                                                                                 // 43
  });                                                                                                                 // 41
}                                                                                                                     // 45
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"3_publish.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/3_publish.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
if (Meteor.isServer) {                                                                                                // 1
  // 数据发布                                                                                                             // 2
  // 发布分类信息, 按照商家发布                                                                                                   // 4
  Meteor.publish("categories_by_seller", function (seller_id) {                                                       // 5
    return Categories.find({                                                                                          // 6
      seller_id: seller_id                                                                                            // 6
    });                                                                                                               // 6
  }); // 发布商品， 按商家发布                                                                                                  // 7
                                                                                                                      //
  Meteor.publish("products_by_seller", function (seller_id, limit) {                                                  // 11
    var limit = limit || 10;                                                                                          // 12
    return Products.find({                                                                                            // 13
      seller_id: seller_id                                                                                            // 13
    }, {                                                                                                              // 13
      limit: limit                                                                                                    // 13
    });                                                                                                               // 13
  }); // 发布商品， 按商家和分类发布                                                                                               // 14
                                                                                                                      //
  Meteor.publish('products_by_category', function (seller_id, category_id, limit, skip) {                             // 18
    var limit = limit || 20;                                                                                          // 19
    var skip = skip || 0;                                                                                             // 20
                                                                                                                      //
    if (!seller_id || !category_id) {                                                                                 // 21
      return this.ready();                                                                                            // 22
    }                                                                                                                 // 23
                                                                                                                      //
    if (category_id === "all") {                                                                                      // 24
      return Products.find({                                                                                          // 25
        seller_id: seller_id                                                                                          // 25
      }, {                                                                                                            // 25
        limit: limit,                                                                                                 // 25
        skip: skip,                                                                                                   // 25
        sort: {                                                                                                       // 25
          createdAt: -1                                                                                               // 25
        }                                                                                                             // 25
      });                                                                                                             // 25
    }                                                                                                                 // 26
                                                                                                                      //
    return Products.find({                                                                                            // 27
      seller_id: seller_id,                                                                                           // 27
      category_id: category_id                                                                                        // 27
    }, {                                                                                                              // 27
      limit: limit,                                                                                                   // 27
      skip: skip,                                                                                                     // 27
      sort: {                                                                                                         // 27
        createdAt: -1                                                                                                 // 27
      }                                                                                                               // 27
    });                                                                                                               // 27
  }); // 发布商品，按照商品ID发布                                                                                                // 28
                                                                                                                      //
  Meteor.publish('product-by-id', function (_id) {                                                                    // 31
    if (!this.userId || !_id) {                                                                                       // 32
      return this.ready();                                                                                            // 33
    }                                                                                                                 // 34
                                                                                                                      //
    return Products.find({                                                                                            // 35
      _id: _id                                                                                                        // 35
    });                                                                                                               // 35
  }); // 发布订单信息， 按照用户 和 状态发布                                                                                          // 36
                                                                                                                      //
  Meteor.publish('user_orders', function (status, limit) {                                                            // 39
    if (!this.userId || !status) {                                                                                    // 40
      return this.ready();                                                                                            // 41
    }                                                                                                                 // 42
                                                                                                                      //
    var limit = limit || 10;                                                                                          // 43
    return Orders.find({                                                                                              // 44
      user_id: this.userId,                                                                                           // 44
      status: status                                                                                                  // 44
    }, {                                                                                                              // 44
      limit: limit                                                                                                    // 44
    });                                                                                                               // 44
  }); // 发布： 按商品id, 和 user_id                                                                                         // 45
                                                                                                                      //
  Meteor.publish('shopping-by-product-id', function (product_id) {                                                    // 48
    if (!this.userId || !product_id) {                                                                                // 49
      return this.ready();                                                                                            // 50
    }                                                                                                                 // 51
                                                                                                                      //
    return Shopping.find({                                                                                            // 52
      user_id: this.userId,                                                                                           // 52
      product_id: product_id                                                                                          // 52
    });                                                                                                               // 52
  }); // 发布： 我的购物车                                                                                                    // 53
                                                                                                                      //
  Meteor.publish('user_shopping', function (limit) {                                                                  // 55
    if (!this.userId) {                                                                                               // 56
      return this.ready();                                                                                            // 57
    }                                                                                                                 // 58
                                                                                                                      //
    var limit = limit || 10;                                                                                          // 59
    return Shopping.find({                                                                                            // 60
      user_id: this.userId                                                                                            // 60
    }, {                                                                                                              // 60
      limit: limit,                                                                                                   // 60
      sort: {                                                                                                         // 60
        createdAt: -1                                                                                                 // 60
      }                                                                                                               // 60
    });                                                                                                               // 60
  }); // 发布订单信息                                                                                                       // 61
                                                                                                                      //
  Meteor.publish('orderInfo', function (_id) {                                                                        // 64
    if (!this.userId || !_id) {                                                                                       // 65
      return this.ready();                                                                                            // 66
    }                                                                                                                 // 67
                                                                                                                      //
    return Orders.find({                                                                                              // 68
      _id: _id                                                                                                        // 68
    });                                                                                                               // 68
  }); // 发布用户的订单列表                                                                                                    // 69
                                                                                                                      //
  Meteor.publish('user-orders', function () {                                                                         // 72
    if (!this.userId) {                                                                                               // 73
      return this.ready();                                                                                            // 74
    }                                                                                                                 // 75
                                                                                                                      //
    return Orders.find({                                                                                              // 76
      user_id: this.userId                                                                                            // 76
    });                                                                                                               // 76
  }); // 发布用户收货地址列表                                                                                                   // 77
                                                                                                                      //
  Meteor.publish('contact_list', function () {                                                                        // 80
    if (!this.userId) {                                                                                               // 81
      return this.ready();                                                                                            // 82
    }                                                                                                                 // 83
                                                                                                                      //
    return Contact.find({                                                                                             // 84
      user_id: this.userId                                                                                            // 84
    }, {                                                                                                              // 84
      sort: {                                                                                                         // 84
        createdAt: -1                                                                                                 // 84
      }                                                                                                               // 84
    });                                                                                                               // 84
  });                                                                                                                 // 85
  Meteor.publish('contactInfo', function (_id) {                                                                      // 87
    if (!this.userId || !_id) {                                                                                       // 88
      return this.ready();                                                                                            // 89
    }                                                                                                                 // 90
                                                                                                                      //
    return Contact.find({                                                                                             // 91
      _id: _id                                                                                                        // 91
    });                                                                                                               // 91
  });                                                                                                                 // 92
}                                                                                                                     // 93
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"4_allows.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/4_allows.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// 数据权限                                                                                                               // 1
// 商品分类权限， 只有商家可以修改                                                                                                   // 3
Categories.allow({                                                                                                    // 4
  insert: function (userId, doc) {                                                                                    // 5
    // the user must be logged in, and the document must be owned by the user                                         // 6
    return userId && doc.seller_id === userId;                                                                        // 7
  },                                                                                                                  // 8
  update: function (userId, doc, fields, modifier) {                                                                  // 9
    // can only change your own documents                                                                             // 10
    return doc.seller_id === userId;                                                                                  // 11
  },                                                                                                                  // 12
  remove: function (userId, doc) {                                                                                    // 13
    // can only remove your own documents                                                                             // 14
    return doc.seller_id === userId;                                                                                  // 15
  }                                                                                                                   // 16
}); // 商品表权限， 只有商家可以修改                                                                                                // 4
                                                                                                                      //
Products.allow({                                                                                                      // 20
  insert: function (userId, doc) {                                                                                    // 21
    // the user must be logged in, and the document must be owned by the user                                         // 22
    return userId && doc.seller_id === userId;                                                                        // 23
  },                                                                                                                  // 24
  update: function (userId, doc, fields, modifier) {                                                                  // 25
    // can only change your own documents                                                                             // 26
    return doc.seller_id === userId;                                                                                  // 27
  },                                                                                                                  // 28
  remove: function (userId, doc) {                                                                                    // 29
    // can only remove your own documents                                                                             // 30
    return doc.seller_id === userId;                                                                                  // 31
  }                                                                                                                   // 32
}); // 订单表权限， 商家拥有全部权限， 用户只有insert 和 update权限                                                                         // 20
                                                                                                                      //
Orders.allow({                                                                                                        // 37
  insert: function (userId, doc) {                                                                                    // 38
    // the user must be logged in, and the document must be owned by the user                                         // 39
    return true;                                                                                                      // 40
  },                                                                                                                  // 41
  update: function (userId, doc, fields, modifier) {                                                                  // 42
    // can only change your own documents                                                                             // 43
    return doc.owner === userId;                                                                                      // 44
  },                                                                                                                  // 45
  remove: function (userId, doc) {                                                                                    // 46
    // can only remove your own documents                                                                             // 47
    return doc.owner === userId;                                                                                      // 48
  }                                                                                                                   // 49
});                                                                                                                   // 37
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"5_weichat_api.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// lib/5_weichat_api.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
// server                                                                                                             // 1
if (Meteor.isServer) {                                                                                                // 2
  getSignatureFromServer = function () {                                                                              // 3
    var token = '',                                                                                                   // 4
        ticket = '',                                                                                                  // 4
        appId = '',                                                                                                   // 4
        appSecret = '';                                                                                               // 4
                                                                                                                      //
    var jsSHA = Npm.require('jssha');                                                                                 // 9
                                                                                                                      //
    var requestUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + appId + '&secret=' + appSecret; // 随机字符串产生函数
                                                                                                                      //
    var createNonceStr = function () {                                                                                // 13
      return Math.random().toString(36).substr(2, 15);                                                                // 14
    }; // 时间戳产生函数                                                                                                     // 15
                                                                                                                      //
                                                                                                                      //
    var createTimeStamp = function () {                                                                               // 18
      return parseInt(new Date().getTime() / 1000) + '';                                                              // 19
    }; // 计算签名                                                                                                        // 20
                                                                                                                      //
                                                                                                                      //
    var calcSignature = function (ticket, noncestr, ts, url) {                                                        // 23
      var str = 'jsapi_ticket=' + ticket + '&noncestr=' + noncestr + '&timestamp=' + ts + '&url=' + url;              // 24
      var shaObj = new jsSHA('SHA-1', 'TEXT');                                                                        // 25
      shaObj.update(str);                                                                                             // 26
      return shaObj.getHash('HEX');                                                                                   // 27
    }; // 获取微信签名所需的 ticket                                                                                            // 28
                                                                                                                      //
                                                                                                                      //
    var generateSignture = function (url) {                                                                           // 31
      var ts = createTimeStamp();                                                                                     // 32
      var nonceStr = createNonceStr();                                                                                // 33
      var signature = calcSignature(ticket, nonceStr, ts, url);                                                       // 34
      console.log('Ticket is ' + ticket + 'Signature is ' + signature);                                               // 35
      var returnSignatures = {                                                                                        // 37
        nonceStr: nonceStr,                                                                                           // 38
        appid: appId,                                                                                                 // 39
        signature: signature,                                                                                         // 40
        url: url                                                                                                      // 41
      };                                                                                                              // 37
      return returnSignatures;                                                                                        // 43
    }; // 获取微信签名所需的 ticket                                                                                            // 44
                                                                                                                      //
                                                                                                                      //
    var updateTicket = function (access_token) {                                                                      // 47
      HTTP.get('https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=' + access_token + '&type=jsapi', function (error, result) {
        if (!error) {                                                                                                 // 49
          var resp = result.data;                                                                                     // 50
          var ticket = resp.ticket;                                                                                   // 51
          console.log('Ticket is ' + ticket);                                                                         // 52
        }                                                                                                             // 53
      });                                                                                                             // 54
    };                                                                                                                // 55
                                                                                                                      //
    var updateTokenAndTicket = function () {                                                                          // 57
      HTTP.get(requestUrl, function (error, result) {                                                                 // 58
        if (!error) {                                                                                                 // 59
          console.log('access_token = ' + JSON.stringify(result.data));                                               // 60
          var token = result.data.access_token;                                                                       // 61
          updateTicket(token);                                                                                        // 62
        }                                                                                                             // 63
      });                                                                                                             // 64
    };                                                                                                                // 65
                                                                                                                      //
    SyncedCron.add({                                                                                                  // 67
      name: 'Update WeChat token and API',                                                                            // 68
      schedule: function (parser) {                                                                                   // 69
        return parser.text('every 1 hour');                                                                           // 70
      },                                                                                                              // 71
      job: function () {                                                                                              // 72
        updateTokenAndTicket();                                                                                       // 73
      }                                                                                                               // 74
    });                                                                                                               // 67
    SyncedCron.start();                                                                                               // 76
    updateTokenAndTicket();                                                                                           // 78
  };                                                                                                                  // 79
}                                                                                                                     // 80
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"method.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/method.js                                                                                                   //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Meteor.methods({                                                                                                      // 2
  'getOrderNumber': function () {                                                                                     // 3
    var now = new Date();                                                                                             // 4
    var today = new Date();                                                                                           // 5
    today.setUTCHours(0, 0, 0, 0);                                                                                    // 6
                                                                                                                      //
    var addZero = function (value) {                                                                                  // 7
      if (value < 10) {                                                                                               // 8
        return '0' + value;                                                                                           // 9
      }                                                                                                               // 10
                                                                                                                      //
      return '' + value;                                                                                              // 11
    };                                                                                                                // 12
                                                                                                                      //
    var orderCountToday = Orders.find({                                                                               // 13
      createdAt: {                                                                                                    // 13
        $gte: today                                                                                                   // 13
      }                                                                                                               // 13
    }).count();                                                                                                       // 13
    orderCountToday += 1;                                                                                             // 15
    var orderNumber = now.getFullYear() + addZero(now.getUTCMonth() + 1) + addZero(now.getUTCDate()) + addZero(now.getUTCHours()) + ("0000000000000000" + orderCountToday).substr(-6);
    return orderNumber;                                                                                               // 17
  }                                                                                                                   // 18
});                                                                                                                   // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wechat-auth.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wechat-auth.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var OAuth = Npm.require('wechat-oauth');                                                                              // 1
                                                                                                                      //
var client = new OAuth('apppid', 'afd33592eb230c2f8f9936881b2383ba');                                                 // 2
var oauthApi = new OAuth('appid', 'sercet', function (openid, callback) {                                             // 4
  Token.getToken(openid, callback);                                                                                   // 5
}, function (openid, token, callback) {                                                                               // 6
  Token.setToken(openid, token, callback);                                                                            // 7
});                                                                                                                   // 8
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var Meteor = void 0;                                                                                                  // 1
module.watch(require("meteor/meteor"), {                                                                              // 1
  Meteor: function (v) {                                                                                              // 1
    Meteor = v;                                                                                                       // 1
  }                                                                                                                   // 1
}, 0);                                                                                                                // 1
Meteor.startup(function () {// code to run on server at startup                                                       // 3
});                                                                                                                   // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/06_router_server.js");
require("./lib/1_startup.js");
require("./lib/2_collections.js");
require("./lib/3_publish.js");
require("./lib/4_allows.js");
require("./lib/5_weichat_api.js");
require("./server/method.js");
require("./server/wechat-auth.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
