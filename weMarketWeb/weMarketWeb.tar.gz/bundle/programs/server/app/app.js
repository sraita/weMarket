var require = meteorInstall({"lib":{"06_router_server.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/06_router_server.js                                                                                       //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 1
  // 微信登录callback                                                                                                // 3
  Router.route('/oauth/wechat', {                                                                                // 4
    where: 'server'                                                                                              // 4
  }).get(function () {                                                                                           // 4
    var appid = 'wxf5fdcd705a634bc9';                                                                            // 5
    var app_secret = 'e1d302d0e7f91b7d989eb42ddbc2ab5e';                                                         // 6
    var userInfo = {};                                                                                           // 7
    var request = this.request;                                                                                  // 9
    var response = this.response;                                                                                // 10
    var returnUrl = '/';                                                                                         // 12
    var Cookies = {};                                                                                            // 14
    this.request.headers.cookie && this.request.headers.cookie.split(';').forEach(function (Cookie) {            // 15
      var parts = Cookie.split("=");                                                                             // 16
      Cookies[parts[0].trim()] = (parts[1] || '').trim();                                                        // 17
    });                                                                                                          // 18
    console.log('cookies ===', JSON.stringify(Cookies));                                                         // 19
                                                                                                                 //
    if (this.request.query.original) {                                                                           // 20
      returnUrl = this.request.query.original;                                                                   // 21
    }                                                                                                            // 22
                                                                                                                 //
    console.log('returnUrl is ' + returnUrl);                                                                    // 23
    returnUrl = decodeURIComponent(returnUrl);                                                                   // 24
    var code = this.request.query.code;                                                                          // 26
    var token_url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' + appid + '&secret=' + app_secret + '&code=' + code + '&grant_type=authorization_code';
    console.log('code = ', code);                                                                                // 30
                                                                                                                 //
    var responseLoginWith = function (openid) {                                                                  // 32
      var result = {};                                                                                           // 33
                                                                                                                 //
      if (openid) {                                                                                              // 34
        result.userId = Meteor.users.findOne({                                                                   // 35
          'services.wechat.openid': openid                                                                       // 35
        })._id;                                                                                                  // 35
      } else {                                                                                                   // 36
        var html = '<html><head><meta http-equiv="content-type" content="text/html;charset=utf-8" /><title>微商传播机</title>';
        html += '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />\r\n';
        html += '<script type="text/javascript">\r\n';                                                           // 39
        html += 'location = "/";';                                                                               // 40
        html += '</script>\r\n';                                                                                 // 41
        html += '</head><body>\r\n';                                                                             // 42
        html += '</body></html>';                                                                                // 43
        response.setHeader('Content-Type', 'text/html; charset=utf-8');                                          // 45
        return response.end(html);                                                                               // 46
      }                                                                                                          // 47
                                                                                                                 //
      var stampedLoginToken = Accounts._generateStampedLoginToken();                                             // 48
                                                                                                                 //
      Accounts._insertLoginToken(result.userId, stampedLoginToken);                                              // 49
                                                                                                                 //
      result = {                                                                                                 // 50
        id: result.userId,                                                                                       // 51
        token: stampedLoginToken.token,                                                                          // 52
        tokenExpires: Accounts._tokenExpiration(stampedLoginToken.when)                                          // 53
      };                                                                                                         // 50
      var html = '<html><head><meta http-equiv="content-type" content="text/html;charset=utf-8" /><title>微商传播机</title>';
      html += '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />\r\n';
      html += '<script type="text/javascript">\r\n';                                                             // 58
      html += 'window.localStorage.setItem("Meteor.userId", "' + result.id + '");';                              // 59
      html += 'window.localStorage.setItem("Meteor.loginToken", "' + result.token + '");';                       // 60
      html += 'window.localStorage.setItem("Meteor.loginTokenExpires", "' + result.tokenExpires + '");';         // 61
      html += 'location = "' + returnUrl + '";';                                                                 // 62
      html += '</script>\r\n';                                                                                   // 63
      html += '</head><body>\r\n';                                                                               // 64
      html += '</body></html>';                                                                                  // 65
      response.setHeader('Content-Type', 'text/html; charset=utf-8');                                            // 67
      response.cookie('meteor_login_token', result.token, {                                                      // 68
        maxAge: Accounts._getTokenLifetimeMs() - 3600 * 1000,                                                    // 68
        path: '/'                                                                                                // 68
      });                                                                                                        // 68
      return response.end(html);                                                                                 // 69
    };                                                                                                           // 70
                                                                                                                 //
    var loginFail = function () {                                                                                // 72
      responseLoginWith();                                                                                       // 73
    };                                                                                                           // 74
                                                                                                                 //
    if (!code) {                                                                                                 // 76
      return loginFail();                                                                                        // 77
    }                                                                                                            // 78
                                                                                                                 //
    var self = this;                                                                                             // 80
    HTTP.get(token_url, function (error, result) {                                                               // 81
      if (!error) {                                                                                              // 82
        var resp = JSON.parse(result.content);                                                                   // 83
        console.log(JSON.stringify(resp));                                                                       // 84
        var access_token = resp.access_token;                                                                    // 85
        var openId = resp.openid;                                                                                // 86
        var user_info_url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' + access_token + '&openid=' + openId + '&lang=zh_CN';
        console.log(user_info_url);                                                                              // 89
        HTTP.get(user_info_url, function (error, result) {                                                       // 91
          if (!error) {                                                                                          // 92
            var resp = JSON.parse(result.content);                                                               // 93
            console.log(JSON.stringify(resp)); // 获得微信用户信息                                                       // 94
                                                                                                                 //
            var profile = {                                                                                      // 96
              name: resp.nickname,                                                                               // 97
              icon: resp.headimgurl,                                                                             // 98
              province: resp.province,                                                                           // 99
              city: resp.city,                                                                                   // 100
              country: resp.country,                                                                             // 101
              sex: resp.sex === '1' || resp.sex === 1 ? '男' : resp.sex === 2 || resp.sex === 2 ? '女' : undefined
            };                                                                                                   // 96
            Accounts.updateOrCreateUserFromExternalService('wechat', {                                           // 105
              id: resp.openid,                                                                                   // 106
              openid: resp.openid,                                                                               // 107
              nickname: resp.nickname,                                                                           // 108
              sex: resp.sex,                                                                                     // 109
              province: resp.province,                                                                           // 110
              city: resp.city,                                                                                   // 111
              country: resp.country,                                                                             // 112
              headimgurl: resp.headimgurl,                                                                       // 113
              privilege: resp.privilege,                                                                         // 114
              unionid: resp.unionid                                                                              // 115
            }, {                                                                                                 // 105
              createdAt: new Date(),                                                                             // 117
              profile: profile                                                                                   // 118
            });                                                                                                  // 116
            Meteor.users.update({                                                                                // 121
              'services.wechat.openid': resp.openid                                                              // 121
            }, {                                                                                                 // 121
              $set: {                                                                                            // 121
                isWeChat: true                                                                                   // 122
              }                                                                                                  // 121
            });                                                                                                  // 121
            return responseLoginWith(resp.openid);                                                               // 125
          } else {                                                                                               // 126
            return loginFail();                                                                                  // 127
          }                                                                                                      // 128
        });                                                                                                      // 129
      } else {                                                                                                   // 130
        return loginFail();                                                                                      // 131
      }                                                                                                          // 132
    });                                                                                                          // 133
  });                                                                                                            // 135
}                                                                                                                // 136
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"1_startup.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/1_startup.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// Meteor.absoluteUrl.defaultOptions.rootUrl = "http://192.168.0.110:3000"                                       // 1
ROOT_URL = (typeof process !== "undefined" && process !== null ? process.env.ROOT_URL : void 0) || "admin-market.raidcdn.cn";
Meteor.absoluteUrl.defaultOptions.rootUrl = ROOT_URL;                                                            // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"2_collections.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/2_collections.js                                                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
//  数据库定义                                                                                                        // 1
function buildRegExp(searchText) {                                                                               // 2
  var words = searchText.trim().split(/[ \-\:]+/);                                                               // 3
                                                                                                                 //
  var exps = _.map(words, function (word) {                                                                      // 4
    return "(?=.*" + word + ")";                                                                                 // 5
  });                                                                                                            // 6
                                                                                                                 //
  var fullExp = exps.join('') + ".+";                                                                            // 7
  return new RegExp(fullExp, "i");                                                                               // 8
} // 产品分类表                                                                                                       // 9
                                                                                                                 //
                                                                                                                 //
Categories = new Mongo.Collection('categories'); // 产品表                                                          // 11
                                                                                                                 //
Products = new Mongo.Collection('products'); // 订单表                                                              // 13
                                                                                                                 //
Orders = new Mongo.Collection('orders'); // 用户购物车                                                                // 15
                                                                                                                 //
Shopping = new Mongo.Collection('shopping'); // 微信token                                                          // 17
                                                                                                                 //
AccessToken = new Mongo.Collection('access_token'); // 用户商品寄送地址信息                                                // 20
                                                                                                                 //
Contact = new Mongo.Collection('contact'); // 分销商销售情况统计                                                          // 23
                                                                                                                 //
SalesOrders = new Mongo.Collection('salesOrders'); // 分销商选中的分销商品列表                                               // 26
                                                                                                                 //
DistributorProducts = new Mongo.Collection('distributorProducts'); // shops 存储店铺表                                // 29
                                                                                                                 //
Shops = new Mongo.Collection('shops');                                                                           // 33
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 35
  // search products                                                                                             // 36
  SearchSource.defineSource('products', function (searchText, options) {                                         // 37
    var options = {                                                                                              // 38
      sort: {                                                                                                    // 38
        createdAt: -1                                                                                            // 38
      }                                                                                                          // 38
    };                                                                                                           // 38
                                                                                                                 //
    if (searchText) {                                                                                            // 40
      var regExp = buildRegExp(searchText);                                                                      // 41
      var selector = {                                                                                           // 42
        name: regExp                                                                                             // 42
      };                                                                                                         // 42
      return Products.find(selector, options).fetch();                                                           // 43
    } else {                                                                                                     // 44
      return Products.find({}, options).fetch();                                                                 // 45
    }                                                                                                            // 46
  });                                                                                                            // 47
}                                                                                                                // 48
                                                                                                                 //
if (Meteor.isClient) {                                                                                           // 50
  ProductsSearch = new SearchSource('products', ['name'], {                                                      // 51
    keepHistory: 1000 * 60 * 5,                                                                                  // 52
    localSearch: true                                                                                            // 53
  });                                                                                                            // 51
}                                                                                                                // 55
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"3_publish.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/3_publish.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 1
  // 数据发布                                                                                                        // 2
  // 发布分类信息, 按照商家发布                                                                                              // 4
  Meteor.publish("categories_by_seller", function (seller_id) {                                                  // 5
    return Categories.find({                                                                                     // 6
      seller_id: seller_id                                                                                       // 6
    });                                                                                                          // 6
  });                                                                                                            // 7
  Meteor.publish("all-categories", function () {                                                                 // 9
    return Categories.find({});                                                                                  // 10
  });                                                                                                            // 11
  Meteor.publish("categories_by_shop", function (shopId) {                                                       // 13
    if (!shopId) {                                                                                               // 14
      return this.ready();                                                                                       // 15
    }                                                                                                            // 16
                                                                                                                 //
    var ids = [];                                                                                                // 17
    var shop = Shops.findOne({                                                                                   // 18
      _id: shopId                                                                                                // 18
    });                                                                                                          // 18
                                                                                                                 //
    if (shop && shop.categories) {                                                                               // 19
      ids = shop.categories;                                                                                     // 20
    }                                                                                                            // 21
                                                                                                                 //
    return Categories.find({                                                                                     // 22
      _id: {                                                                                                     // 22
        $in: ids                                                                                                 // 22
      }                                                                                                          // 22
    }, {                                                                                                         // 22
      sort: {                                                                                                    // 22
        createdAt: -1                                                                                            // 22
      }                                                                                                          // 22
    });                                                                                                          // 22
  }); // 发布所有商品                                                                                                  // 23
                                                                                                                 //
  Meteor.publish('all-products', function (limit) {                                                              // 25
    var limit = limit || 10;                                                                                     // 26
    return Products.find({}, {                                                                                   // 27
      limit: limit                                                                                               // 27
    }, {                                                                                                         // 27
      sort: {                                                                                                    // 27
        createdAt: -1                                                                                            // 27
      }                                                                                                          // 27
    });                                                                                                          // 27
  }); // 发布商品， 按商家发布                                                                                             // 28
                                                                                                                 //
  Meteor.publish("products_by_seller", function (seller_id, limit) {                                             // 31
    var limit = limit || 10;                                                                                     // 32
    return Products.find({                                                                                       // 33
      seller_id: seller_id                                                                                       // 33
    }, {                                                                                                         // 33
      limit: limit                                                                                               // 33
    });                                                                                                          // 33
  }); // 发布商品， 按分销商发布                                                                                            // 34
                                                                                                                 //
  Meteor.publish("products_by_distributor", function (distributor_id, limit) {                                   // 37
    var limit = limit || 10;                                                                                     // 38
    return DistributorProducts.find({                                                                            // 39
      distributor_id: distributor_id                                                                             // 39
    }, {                                                                                                         // 39
      limit: limit                                                                                               // 39
    });                                                                                                          // 39
  }); // 发布商品， 按分类发布                                                                                             // 40
                                                                                                                 //
  Meteor.publish('products_by_category', function (category_id, limit, skip) {                                   // 42
    var limit = limit || 20;                                                                                     // 43
    var skip = skip || 0;                                                                                        // 44
                                                                                                                 //
    if (!category_id) {                                                                                          // 45
      return this.ready();                                                                                       // 46
    }                                                                                                            // 47
                                                                                                                 //
    if (category_id === "all") {                                                                                 // 48
      return Products.find({}, {                                                                                 // 49
        limit: limit,                                                                                            // 49
        skip: skip,                                                                                              // 49
        sort: {                                                                                                  // 49
          createdAt: -1                                                                                          // 49
        }                                                                                                        // 49
      });                                                                                                        // 49
    }                                                                                                            // 50
                                                                                                                 //
    return Products.find({                                                                                       // 51
      category_id: category_id                                                                                   // 51
    }, {                                                                                                         // 51
      limit: limit,                                                                                              // 51
      skip: skip,                                                                                                // 51
      sort: {                                                                                                    // 51
        createdAt: -1                                                                                            // 51
      }                                                                                                          // 51
    });                                                                                                          // 51
  });                                                                                                            // 52
  Meteor.publish('shop_categories', function (shopId) {                                                          // 54
    if (!shopId) {                                                                                               // 55
      return this.ready();                                                                                       // 56
    }                                                                                                            // 57
                                                                                                                 //
    var shop = Shops.findOne({                                                                                   // 58
      _id: shopId                                                                                                // 58
    });                                                                                                          // 58
                                                                                                                 //
    if (!shop) {                                                                                                 // 59
      return this.ready();                                                                                       // 60
    }                                                                                                            // 61
                                                                                                                 //
    return Categories.find({                                                                                     // 62
      _id: {                                                                                                     // 62
        $in: shop.categories                                                                                     // 62
      }                                                                                                          // 62
    });                                                                                                          // 62
  });                                                                                                            // 63
  Meteor.publish('shop_products', function (shopId, category_id, limit, skip) {                                  // 65
    var limit = limit || 20;                                                                                     // 66
    var skip = skip || 0;                                                                                        // 67
                                                                                                                 //
    if (!shopId || !category_id) {                                                                               // 68
      return this.ready();                                                                                       // 69
    }                                                                                                            // 70
                                                                                                                 //
    var shop = Shops.findOne({                                                                                   // 71
      _id: shopId                                                                                                // 71
    });                                                                                                          // 71
                                                                                                                 //
    if (!shop) {                                                                                                 // 72
      return this.ready();                                                                                       // 73
    }                                                                                                            // 74
                                                                                                                 //
    if (category_id === "all") {                                                                                 // 75
      return Products.find({                                                                                     // 76
        category_id: {                                                                                           // 76
          $in: shop.categories                                                                                   // 76
        }                                                                                                        // 76
      }, {                                                                                                       // 76
        limit: limit,                                                                                            // 76
        skip: skip,                                                                                              // 76
        sort: {                                                                                                  // 76
          createdAt: -1                                                                                          // 76
        }                                                                                                        // 76
      });                                                                                                        // 76
    }                                                                                                            // 77
                                                                                                                 //
    return Products.find({                                                                                       // 78
      category_id: category_id                                                                                   // 78
    }, {                                                                                                         // 78
      limit: limit,                                                                                              // 78
      skip: skip,                                                                                                // 78
      sort: {                                                                                                    // 78
        createdAt: -1                                                                                            // 78
      }                                                                                                          // 78
    });                                                                                                          // 78
  }); // 发布商品，按照商品ID发布                                                                                           // 79
                                                                                                                 //
  Meteor.publish('product-by-id', function (_id) {                                                               // 82
    if (!this.userId || !_id) {                                                                                  // 83
      return this.ready();                                                                                       // 84
    }                                                                                                            // 85
                                                                                                                 //
    return [DistributorProducts.find({                                                                           // 86
      product_id: _id,                                                                                           // 87
      distributor_id: this.userId                                                                                // 87
    }), Products.find({                                                                                          // 87
      _id: _id                                                                                                   // 88
    })];                                                                                                         // 88
  });                                                                                                            // 90
  Meteor.publish('userDistributorProductInfo', function (_id) {                                                  // 92
    if (!this.userId || !_id) {                                                                                  // 93
      return this.ready();                                                                                       // 94
    }                                                                                                            // 95
                                                                                                                 //
    return DistributorProducts.find({                                                                            // 96
      product_id: _id,                                                                                           // 96
      distributor_id: this.userId                                                                                // 96
    });                                                                                                          // 96
  });                                                                                                            // 97
  Meteor.publish('distributorProductById', function (_id) {                                                      // 99
    if (!_id) {                                                                                                  // 100
      return this.ready();                                                                                       // 101
    }                                                                                                            // 102
                                                                                                                 //
    return DistributorProducts.find({                                                                            // 103
      _id: _id                                                                                                   // 103
    });                                                                                                          // 103
  }); // 发布订单信息， 按照用户 和 状态发布                                                                                     // 104
                                                                                                                 //
  Meteor.publish('user_orders', function (status, limit) {                                                       // 107
    if (!this.userId || !status) {                                                                               // 108
      return this.ready();                                                                                       // 109
    }                                                                                                            // 110
                                                                                                                 //
    var limit = limit || 10;                                                                                     // 111
    return Orders.find({                                                                                         // 112
      user_id: this.userId,                                                                                      // 112
      status: status                                                                                             // 112
    }, {                                                                                                         // 112
      limit: limit                                                                                               // 112
    });                                                                                                          // 112
  }); // 发布订单信息， 按照商家 和 状态发布                                                                                     // 113
                                                                                                                 //
  Meteor.publish('seller_orders', function (seller_id, status, limit, skip) {                                    // 116
    if (!seller_id || !status) {                                                                                 // 117
      return this.ready();                                                                                       // 118
    }                                                                                                            // 119
                                                                                                                 //
    var limit = limit || 20;                                                                                     // 120
    var skip = skip || 0;                                                                                        // 121
                                                                                                                 //
    if (status == 'all') {                                                                                       // 122
      return Orders.find({                                                                                       // 123
        seller_id: seller_id                                                                                     // 123
      }, {                                                                                                       // 123
        limit: limit,                                                                                            // 123
        skip: skip                                                                                               // 123
      });                                                                                                        // 123
    } else {                                                                                                     // 124
      status = parseInt(status);                                                                                 // 125
      return Orders.find({                                                                                       // 126
        seller_id: seller_id,                                                                                    // 126
        status: status                                                                                           // 126
      }, {                                                                                                       // 126
        limit: limit,                                                                                            // 126
        skip: skip                                                                                               // 126
      });                                                                                                        // 126
    }                                                                                                            // 127
  }); // 发布： 按商品id, 和 user_id                                                                                    // 128
                                                                                                                 //
  Meteor.publish('shopping-by-product-id', function (product_id) {                                               // 131
    if (!this.userId || !product_id) {                                                                           // 132
      return this.ready();                                                                                       // 133
    }                                                                                                            // 134
                                                                                                                 //
    return Shopping.find({                                                                                       // 135
      user_id: this.userId,                                                                                      // 135
      product_id: product_id                                                                                     // 135
    });                                                                                                          // 135
  }); // 发布： 我的购物车                                                                                               // 136
                                                                                                                 //
  Meteor.publish('user_shopping', function (limit) {                                                             // 138
    if (!this.userId) {                                                                                          // 139
      return this.ready();                                                                                       // 140
    }                                                                                                            // 141
                                                                                                                 //
    var limit = limit || 10;                                                                                     // 142
    return Shopping.find({                                                                                       // 143
      user_id: this.userId                                                                                       // 143
    }, {                                                                                                         // 143
      limit: limit,                                                                                              // 143
      sort: {                                                                                                    // 143
        createdAt: -1                                                                                            // 143
      }                                                                                                          // 143
    });                                                                                                          // 143
  }); // 发布订单信息                                                                                                  // 144
                                                                                                                 //
  Meteor.publish('orderInfo', function (_id) {                                                                   // 147
    if (!this.userId || !_id) {                                                                                  // 148
      return this.ready();                                                                                       // 149
    }                                                                                                            // 150
                                                                                                                 //
    return Orders.find({                                                                                         // 151
      _id: _id                                                                                                   // 151
    });                                                                                                          // 151
  }); // 发布用户的订单列表                                                                                               // 152
                                                                                                                 //
  Meteor.publish('user-orders', function () {                                                                    // 155
    if (!this.userId) {                                                                                          // 156
      return this.ready();                                                                                       // 157
    }                                                                                                            // 158
                                                                                                                 //
    return Orders.find({                                                                                         // 159
      user_id: this.userId                                                                                       // 159
    });                                                                                                          // 159
  }); // 发布用户收货地址列表                                                                                              // 160
                                                                                                                 //
  Meteor.publish('contact_list', function () {                                                                   // 163
    if (!this.userId) {                                                                                          // 164
      return this.ready();                                                                                       // 165
    }                                                                                                            // 166
                                                                                                                 //
    return Contact.find({                                                                                        // 167
      user_id: this.userId                                                                                       // 167
    }, {                                                                                                         // 167
      sort: {                                                                                                    // 167
        createdAt: -1                                                                                            // 167
      }                                                                                                          // 167
    });                                                                                                          // 167
  });                                                                                                            // 168
  Meteor.publish('contactInfo', function (_id) {                                                                 // 170
    if (!this.userId || !_id) {                                                                                  // 171
      return this.ready();                                                                                       // 172
    }                                                                                                            // 173
                                                                                                                 //
    return Contact.find({                                                                                        // 174
      _id: _id                                                                                                   // 174
    });                                                                                                          // 174
  }); // 经销商销售情况统计 ，按经销商id                                                                                       // 175
                                                                                                                 //
  Meteor.publish('saleOrders', function () {                                                                     // 178
    if (!this.userId) {                                                                                          // 179
      return this.ready();                                                                                       // 180
    } else {                                                                                                     // 181
      return SalesOrders.find({                                                                                  // 182
        shop_id: this.userId                                                                                     // 182
      });                                                                                                        // 182
    }                                                                                                            // 183
  }); // 发布店铺信息                                                                                                  // 184
                                                                                                                 //
  Meteor.publish('shopInfo', function (_id) {                                                                    // 187
    if (!_id) {                                                                                                  // 188
      return this.ready();                                                                                       // 189
    }                                                                                                            // 190
                                                                                                                 //
    return Shops.find({                                                                                          // 191
      _id: _id                                                                                                   // 191
    });                                                                                                          // 191
  });                                                                                                            // 192
  Meteor.publish('distributorUserCounts', function () {                                                          // 194
    Counts.publish(this, 'distributorSaleOrderCounts-complate', SalesOrders.find({                               // 195
      'shop_id': this.userId,                                                                                    // 195
      'status': 'complate'                                                                                       // 195
    }));                                                                                                         // 195
    Counts.publish(this, 'distributorSaleOrderCounts-waiting', SalesOrders.find({                                // 196
      'shop_id': this.userId,                                                                                    // 196
      'status': 'waiting'                                                                                        // 196
    }));                                                                                                         // 196
  });                                                                                                            // 197
}                                                                                                                // 198
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"4_allows.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/4_allows.js                                                                                               //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// 创建新订单同时， 创建分销商相应佣金记录                                                                                          // 1
var orderInsertHookHandle = function (doc) {                                                                     // 2
  console.log(JSON.stringify(doc));                                                                              // 3
  Meteor.defer(function () {                                                                                     // 4
    doc.products.forEach(function (item) {                                                                       // 5
      var profit_price = 0;                                                                                      // 6
      profit_price = item.profit_price * item.product_num;                                                       // 7
      profit_price = profit_price.toFixed(2);                                                                    // 8
      var obj = {                                                                                                // 9
        "order_no": doc.order_no,                                                                                // 10
        // 订单号                                                                                                   // 10
        "product_id": item.product_id,                                                                           // 11
        // 订单商品id                                                                                                // 11
        "product_name": item.product_name,                                                                       // 12
        // 订单商品名称                                                                                                // 12
        "product_img": item.product_img,                                                                         // 13
        // 商家信息                                                                                                  // 14
        "seller_id": item.seller_id,                                                                             // 15
        // 商家 ID                                                                                                 // 15
        "seller_name": item.seller_name,                                                                         // 16
        // 商家名称                                                                                                  // 16
        "seller_icon": item.seller_icon,                                                                         // 17
        // 商家头像                                                                                                  // 17
        // 分销商信息                                                                                                 // 19
        "shop_id": item.shopId,                                                                                  // 20
        "profit_price": item.profit_price,                                                                       // 22
        // 分销商每销售成功一件可获利金额                                                                                       // 22
        // 订单信息                                                                                                  // 23
        "price": item.product_price,                                                                             // 24
        // 订单单价                                                                                                  // 24
        "product_number": item.product_num,                                                                      // 25
        // 订单商品数量                                                                                                // 25
        "total_price": doc.total_price,                                                                          // 26
        // 订单总价                                                                                                  // 26
        "createdAt": new Date(),                                                                                 // 27
        // 下单时间                                                                                                  // 27
        "profit_price": profit_price,                                                                            // 29
        // 分成金额                                                                                                  // 29
        "status": 'waiting',                                                                                     // 31
        // 状态： 'complate'(已完成) || 'waiting'(进行中) || 'failed'(用户退款)                                               // 31
        // 下单人信息                                                                                                 // 33
        "user_id": doc.user_id,                                                                                  // 34
        // 下单人id,                                                                                                // 34
        "user_name": doc.user_name,                                                                              // 35
        // 下单人名称                                                                                                 // 35
        "user_icon": doc.user_icon // 下单人ICON                                                                    // 36
                                                                                                                 //
      };                                                                                                         // 9
      SalesOrders.insert(obj);                                                                                   // 38
    });                                                                                                          // 39
  });                                                                                                            // 40
}; // 更新订单的同时，更新分销商相应的佣金记录                                                                                       // 41
                                                                                                                 //
                                                                                                                 //
var orderUpdateHookHandle = function (doc, fieldNames, modifier) {                                               // 43
  if (modifier.$set.status == 0) {                                                                               // 45
    Meteor.defer(function () {                                                                                   // 46
      SalesOrders.update({                                                                                       // 47
        order_no: doc.order_no                                                                                   // 47
      }, {                                                                                                       // 47
        $set: {                                                                                                  // 48
          'status': 'failed',                                                                                    // 49
          'fail_reson': '用户取消了订单'                                                                                // 50
        }                                                                                                        // 48
      }, {                                                                                                       // 47
        multi: true                                                                                              // 52
      });                                                                                                        // 52
    });                                                                                                          // 53
  }                                                                                                              // 54
                                                                                                                 //
  if (modifier.$set.status == 5) {                                                                               // 55
    Meteor.defer(function () {                                                                                   // 56
      SalesOrders.update({                                                                                       // 57
        order_no: doc.order_no                                                                                   // 57
      }, {                                                                                                       // 57
        $set: {                                                                                                  // 58
          'status': 'complate'                                                                                   // 59
        }                                                                                                        // 58
      }, {                                                                                                       // 57
        multi: true                                                                                              // 61
      });                                                                                                        // 61
    }); // 更新用户下的佣金总额已经用户店铺下的佣金总额                                                                                // 62
                                                                                                                 //
    SalesOrders.find({                                                                                           // 64
      order_no: doc.order_no                                                                                     // 64
    }).forEach(function (item) {                                                                                 // 64
      // console.log(item);                                                                                      // 65
      var amount = parseFloat(item.profit_price); // 金额                                                          // 66
                                                                                                                 //
      Meteor.users.update({                                                                                      // 67
        _id: item.shop_id                                                                                        // 67
      }, {                                                                                                       // 67
        $inc: {                                                                                                  // 68
          'profile.brokerage': amount,                                                                           // 69
          //佣金                                                                                                   // 69
          'profile.balance': amount // 余额                                                                        // 70
                                                                                                                 //
        }                                                                                                        // 68
      });                                                                                                        // 67
      Shops.update({                                                                                             // 73
        _id: item.shop_id                                                                                        // 73
      }, {                                                                                                       // 73
        $inc: {                                                                                                  // 74
          brokerage: amount //佣金                                                                                 // 75
                                                                                                                 //
        }                                                                                                        // 74
      });                                                                                                        // 73
    });                                                                                                          // 78
  }                                                                                                              // 79
}; // 数据权限                                                                                                       // 81
// 商品分类权限， 只有商家可以修改                                                                                              // 85
                                                                                                                 //
                                                                                                                 //
Categories.allow({                                                                                               // 86
  insert: function (userId, doc) {                                                                               // 87
    // the user must be logged in, and the document must be owned by the user                                    // 88
    return userId && doc.seller_id === userId;                                                                   // 89
  },                                                                                                             // 90
  update: function (userId, doc, fields, modifier) {                                                             // 91
    // can only change your own documents                                                                        // 92
    return doc.seller_id === userId;                                                                             // 93
  },                                                                                                             // 94
  remove: function (userId, doc) {                                                                               // 95
    // can only remove your own documents                                                                        // 96
    return doc.seller_id === userId;                                                                             // 97
  }                                                                                                              // 98
}); // 商品表权限， 只有商家可以修改                                                                                           // 86
                                                                                                                 //
Products.allow({                                                                                                 // 102
  insert: function (userId, doc) {                                                                               // 103
    // the user must be logged in, and the document must be owned by the user                                    // 104
    return userId && doc.seller_id === userId;                                                                   // 105
  },                                                                                                             // 106
  update: function (userId, doc, fields, modifier) {                                                             // 107
    // can only change your own documents                                                                        // 108
    return doc.seller_id === userId;                                                                             // 109
  },                                                                                                             // 110
  remove: function (userId, doc) {                                                                               // 111
    // can only remove your own documents                                                                        // 112
    return doc.seller_id === userId;                                                                             // 113
  }                                                                                                              // 114
}); // 订单表权限， 商家拥有全部权限， 用户只有insert 和 update权限                                                                    // 102
                                                                                                                 //
Orders.allow({                                                                                                   // 119
  insert: function (userId, doc) {                                                                               // 120
    // the user must be logged in, and the document must be owned by the user                                    // 121
    orderInsertHookHandle(doc);                                                                                  // 122
    return true;                                                                                                 // 123
  },                                                                                                             // 124
  update: function (userId, doc, fieldNames, modifier) {                                                         // 125
    // can only change your own documents                                                                        // 126
    if (fieldNames && fieldNames.indexOf('status') > -1) {                                                       // 127
      console.log(modifier.$set.status);                                                                         // 128
      orderUpdateHookHandle(doc, fieldNames, modifier);                                                          // 129
    }                                                                                                            // 130
                                                                                                                 //
    return true;                                                                                                 // 131
  },                                                                                                             // 132
  remove: function (userId, doc) {                                                                               // 133
    // can only remove your own documents                                                                        // 134
    return doc.owner === userId;                                                                                 // 135
  }                                                                                                              // 136
}); // 店铺信息权限， 只有店铺创建者才有相关权限                                                                                     // 119
                                                                                                                 //
Shops.allow({                                                                                                    // 140
  insert: function (userId, doc) {                                                                               // 141
    return userId == doc._id;                                                                                    // 142
  },                                                                                                             // 143
  update: function (userId, doc) {                                                                               // 144
    return userId == doc._id;                                                                                    // 145
  },                                                                                                             // 146
  remove: function (userId, doc) {                                                                               // 147
    return userId == doc._id;                                                                                    // 148
  }                                                                                                              // 149
});                                                                                                              // 140
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"5_weichat_api.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/5_weichat_api.js                                                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// server                                                                                                        // 1
if (Meteor.isServer) {                                                                                           // 2
  var token = '',                                                                                                // 4
      ticket = '',                                                                                               // 4
      appId = 'wxf5fdcd705a634bc9',                                                                              // 4
      appSecret = 'e1d302d0e7f91b7d989eb42ddbc2ab5e';                                                            // 4
                                                                                                                 //
  var jsSHA = Npm.require('jssha');                                                                              // 9
                                                                                                                 //
  var requestUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + appId + '&secret=' + appSecret; // 随机字符串产生函数
                                                                                                                 //
  var createNonceStr = function () {                                                                             // 13
    return Math.random().toString(36).substr(2, 15);                                                             // 14
  }; // 时间戳产生函数                                                                                                  // 15
                                                                                                                 //
                                                                                                                 //
  var createTimeStamp = function () {                                                                            // 18
    return parseInt(new Date().getTime() / 1000) + '';                                                           // 19
  }; // 计算签名                                                                                                     // 20
                                                                                                                 //
                                                                                                                 //
  var calcSignature = function (ticket, noncestr, ts, url) {                                                     // 23
    var str = 'jsapi_ticket=' + ticket + '&noncestr=' + noncestr + '&timestamp=' + ts + '&url=' + url;           // 24
    var shaObj = new jsSHA('SHA-1', 'TEXT');                                                                     // 25
    shaObj.update(str);                                                                                          // 26
    return shaObj.getHash('HEX');                                                                                // 27
  }; // 获取微信签名所需的 ticket                                                                                         // 28
                                                                                                                 //
                                                                                                                 //
  var generateSignture = function (url) {                                                                        // 31
    var ts = createTimeStamp();                                                                                  // 32
    var nonceStr = createNonceStr();                                                                             // 33
    var signature = calcSignature(ticket, nonceStr, ts, url);                                                    // 34
    console.log('Ticket is ' + ticket + 'Signature is ' + signature);                                            // 35
    var returnSignatures = {                                                                                     // 37
      nonceStr: nonceStr,                                                                                        // 38
      appid: appId,                                                                                              // 39
      timestamp: ts,                                                                                             // 40
      signature: signature,                                                                                      // 41
      url: url                                                                                                   // 42
    };                                                                                                           // 37
    return returnSignatures;                                                                                     // 44
  }; // 获取微信签名所需的 ticket                                                                                         // 45
                                                                                                                 //
                                                                                                                 //
  var updateTicket = function (access_token) {                                                                   // 48
    HTTP.get('https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=' + access_token + '&type=jsapi', function (error, result) {
      if (!error) {                                                                                              // 50
        var resp = result.data;                                                                                  // 51
        ticket = resp.ticket;                                                                                    // 52
        console.log('Ticket is ' + ticket);                                                                      // 53
      }                                                                                                          // 54
    });                                                                                                          // 55
  };                                                                                                             // 56
                                                                                                                 //
  var updateTokenAndTicket = function () {                                                                       // 58
    HTTP.get(requestUrl, function (error, result) {                                                              // 59
      if (!error) {                                                                                              // 60
        console.log('access_token = ' + JSON.stringify(result.data));                                            // 61
        var token = result.data.access_token;                                                                    // 62
        updateTicket(token);                                                                                     // 63
      }                                                                                                          // 64
    });                                                                                                          // 65
  };                                                                                                             // 66
                                                                                                                 //
  updateTokenAndTicket();                                                                                        // 67
  Meteor.setInterval(function () {                                                                               // 68
    updateTokenAndTicket();                                                                                      // 69
  }, 60 * 60 * 1000);                                                                                            // 70
  Router.route('/sign/:url', {                                                                                   // 72
    where: 'server'                                                                                              // 72
  }).get(function () {                                                                                           // 72
    var originalUrl = this.request.originalUrl;                                                                  // 73
    var url = originalUrl.slice(6, originalUrl.length);                                                          // 74
    url = decodeURIComponent(url);                                                                               // 75
    console.log('To sign this url: ' + url);                                                                     // 76
    var result = generateSignture(url);                                                                          // 77
    this.response.end(JSON.stringify(result));                                                                   // 78
  });                                                                                                            // 79
}                                                                                                                // 80
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"method.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/method.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
Meteor.methods({                                                                                                 // 2
  'getOrderNumber': function () {                                                                                // 3
    var now = new Date();                                                                                        // 4
    var today = new Date();                                                                                      // 5
    today.setUTCHours(0, 0, 0, 0);                                                                               // 6
                                                                                                                 //
    var addZero = function (value) {                                                                             // 7
      if (value < 10) {                                                                                          // 8
        return '0' + value;                                                                                      // 9
      }                                                                                                          // 10
                                                                                                                 //
      return '' + value;                                                                                         // 11
    };                                                                                                           // 12
                                                                                                                 //
    var orderCountToday = Orders.find({                                                                          // 13
      createdAt: {                                                                                               // 13
        $gte: today                                                                                              // 13
      }                                                                                                          // 13
    }).count();                                                                                                  // 13
    orderCountToday += 1;                                                                                        // 15
    var orderNumber = now.getFullYear() + addZero(now.getUTCMonth() + 1) + addZero(now.getUTCDate()) + addZero(now.getUTCHours()) + ("0000000000000000" + orderCountToday).substr(-6);
    return orderNumber;                                                                                          // 17
  },                                                                                                             // 18
  'updateUserRole': function (userId, role) {                                                                    // 19
    Meteor.users.update({                                                                                        // 20
      _id: userId                                                                                                // 20
    }, {                                                                                                         // 20
      $set: {                                                                                                    // 21
        'profile.role': role                                                                                     // 21
      }                                                                                                          // 21
    }); // 创建相应的店铺                                                                                               // 20
                                                                                                                 //
    var user = Meteor.users.findOne({                                                                            // 25
      _id: userId                                                                                                // 25
    });                                                                                                          // 25
    var shop = Shops.findOne({                                                                                   // 26
      _id: userId                                                                                                // 26
    });                                                                                                          // 26
    console.log(JSON.stringify(user));                                                                           // 27
    var categories = [];                                                                                         // 28
                                                                                                                 //
    if (!shop) {                                                                                                 // 29
      var categories = [];                                                                                       // 30
      Categories.find({}).forEach(function (item) {                                                              // 31
        categories.push(item._id);                                                                               // 32
      });                                                                                                        // 33
      return Shops.insert({                                                                                      // 34
        _id: userId,                                                                                             // 35
        icon: user.profile && user.profile.icon ? user.profile.icon : '/img/userPicture.png',                    // 36
        name: user.profile && user.profile.nickname ? user.profile.nickname + '的店铺' : '',                        // 37
        categories: categories                                                                                   // 38
      });                                                                                                        // 34
    } else {                                                                                                     // 40
      return true;                                                                                               // 41
    }                                                                                                            // 42
  }                                                                                                              // 43
});                                                                                                              // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wechat-auth.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/wechat-auth.js                                                                                         //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var OAuth = Npm.require('wechat-oauth');                                                                         // 1
                                                                                                                 //
var client = new OAuth('apppid', 'afd33592eb230c2f8f9936881b2383ba');                                            // 2
var oauthApi = new OAuth('appid', 'sercet', function (openid, callback) {                                        // 4
  Token.getToken(openid, callback);                                                                              // 5
}, function (openid, token, callback) {                                                                          // 6
  Token.setToken(openid, token, callback);                                                                       // 7
});                                                                                                              // 8
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/main.js                                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor = void 0;                                                                                             // 1
module.watch(require("meteor/meteor"), {                                                                         // 1
  Meteor: function (v) {                                                                                         // 1
    Meteor = v;                                                                                                  // 1
  }                                                                                                              // 1
}, 0);                                                                                                           // 1
Meteor.startup(function () {// code to run on server at startup                                                  // 3
});                                                                                                              // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/06_router_server.js");
require("./lib/1_startup.js");
require("./lib/2_collections.js");
require("./lib/3_publish.js");
require("./lib/4_allows.js");
require("./lib/5_weichat_api.js");
require("./server/method.js");
require("./server/wechat-auth.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
