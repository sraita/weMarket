var require = meteorInstall({"lib":{"06_router_server.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/06_router_server.js                                                                                       //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 1
  // 微信登录callback                                                                                                // 3
  Router.route('/oauth/wechat', {                                                                                // 4
    where: 'server'                                                                                              // 4
  }).get(function () {                                                                                           // 4
    var appid = 'wxf5fdcd705a634bc9';                                                                            // 5
    var app_secret = 'e1d302d0e7f91b7d989eb42ddbc2ab5e';                                                         // 6
    var userInfo = {};                                                                                           // 7
    var request = this.request;                                                                                  // 9
    var response = this.response;                                                                                // 10
    var returnUrl = '/';                                                                                         // 12
    var Cookies = {};                                                                                            // 14
    this.request.headers.cookie && this.request.headers.cookie.split(';').forEach(function (Cookie) {            // 15
      var parts = Cookie.split("=");                                                                             // 16
      Cookies[parts[0].trim()] = (parts[1] || '').trim();                                                        // 17
    });                                                                                                          // 18
                                                                                                                 //
    if (Cookies.originalUrl) {                                                                                   // 20
      returnUrl = Cookies.originalUrl;                                                                           // 21
    }                                                                                                            // 22
                                                                                                                 //
    returnUrl = decodeURIComponent(returnUrl);                                                                   // 24
    var code = this.request.query.code;                                                                          // 26
    var token_url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' + appid + '&secret=' + app_secret + '&code=' + code + '&grant_type=authorization_code';
    console.log('code = ', code);                                                                                // 30
                                                                                                                 //
    var responseLoginWith = function (openid) {                                                                  // 32
      var result = {};                                                                                           // 33
                                                                                                                 //
      if (openid) {                                                                                              // 34
        result.userId = Meteor.users.findOne({                                                                   // 35
          'services.wechat.openid': openid                                                                       // 35
        })._id;                                                                                                  // 35
      } else {                                                                                                   // 36
        var html = '<html><head><meta http-equiv="content-type" content="text/html;charset=utf-8" /><title>微商传播机</title>';
        html += '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />\r\n';
        html += '<script type="text/javascript">\r\n';                                                           // 39
        html += 'location = "/";';                                                                               // 40
        html += '</script>\r\n';                                                                                 // 41
        html += '</head><body>\r\n';                                                                             // 42
        html += '</body></html>';                                                                                // 43
        response.setHeader('Content-Type', 'text/html; charset=utf-8');                                          // 45
        return response.end(html);                                                                               // 46
      }                                                                                                          // 47
                                                                                                                 //
      var stampedLoginToken = Accounts._generateStampedLoginToken();                                             // 48
                                                                                                                 //
      Accounts._insertLoginToken(result.userId, stampedLoginToken);                                              // 49
                                                                                                                 //
      result = {                                                                                                 // 50
        id: result.userId,                                                                                       // 51
        token: stampedLoginToken.token,                                                                          // 52
        tokenExpires: Accounts._tokenExpiration(stampedLoginToken.when)                                          // 53
      };                                                                                                         // 50
      var html = '<html><head><meta http-equiv="content-type" content="text/html;charset=utf-8" /><title>微商传播机</title>';
      html += '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />\r\n';
      html += '<script type="text/javascript">\r\n';                                                             // 58
      html += 'window.localStorage.setItem("Meteor.userId", "' + result.id + '");';                              // 59
      html += 'window.localStorage.setItem("Meteor.loginToken", "' + result.token + '");';                       // 60
      html += 'window.localStorage.setItem("Meteor.loginTokenExpires", "' + result.tokenExpires + '");';         // 61
      html += 'location = "' + returnUrl + '";';                                                                 // 62
      html += '</script>\r\n';                                                                                   // 63
      html += '</head><body>\r\n';                                                                               // 64
      html += '</body></html>';                                                                                  // 65
      response.setHeader('Content-Type', 'text/html; charset=utf-8');                                            // 67
      response.cookie('meteor_login_token', result.token, {                                                      // 68
        maxAge: Accounts._getTokenLifetimeMs() - 3600 * 1000,                                                    // 68
        path: '/'                                                                                                // 68
      });                                                                                                        // 68
      return response.end(html);                                                                                 // 69
    };                                                                                                           // 70
                                                                                                                 //
    var loginFail = function () {                                                                                // 72
      responseLoginWith();                                                                                       // 73
    };                                                                                                           // 74
                                                                                                                 //
    if (!code) {                                                                                                 // 76
      return loginFail();                                                                                        // 77
    }                                                                                                            // 78
                                                                                                                 //
    var self = this;                                                                                             // 80
    HTTP.get(token_url, function (error, result) {                                                               // 81
      if (!error) {                                                                                              // 82
        var resp = JSON.parse(result.content);                                                                   // 83
        console.log(JSON.stringify(resp));                                                                       // 84
        var access_token = resp.access_token;                                                                    // 85
        var openId = resp.openid;                                                                                // 86
        var user_info_url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' + access_token + '&openid=' + openId + '&lang=zh_CN';
        console.log(user_info_url);                                                                              // 89
        HTTP.get(user_info_url, function (error, result) {                                                       // 91
          if (!error) {                                                                                          // 92
            var resp = JSON.parse(result.content);                                                               // 93
            console.log(JSON.stringify(resp)); // 获得微信用户信息                                                       // 94
                                                                                                                 //
            var profile = {                                                                                      // 96
              name: resp.nickname,                                                                               // 97
              icon: resp.headimgurl,                                                                             // 98
              province: resp.province,                                                                           // 99
              city: resp.city,                                                                                   // 100
              country: resp.country,                                                                             // 101
              sex: resp.sex === '1' || resp.sex === 1 ? '男' : resp.sex === 2 || resp.sex === 2 ? '女' : undefined
            };                                                                                                   // 96
            Accounts.updateOrCreateUserFromExternalService('wechat', {                                           // 105
              id: resp.openid,                                                                                   // 106
              openid: resp.openid,                                                                               // 107
              nickname: resp.nickname,                                                                           // 108
              sex: resp.sex,                                                                                     // 109
              province: resp.province,                                                                           // 110
              city: resp.city,                                                                                   // 111
              country: resp.country,                                                                             // 112
              headimgurl: resp.headimgurl,                                                                       // 113
              privilege: resp.privilege,                                                                         // 114
              unionid: resp.unionid                                                                              // 115
            }, {                                                                                                 // 105
              createdAt: new Date(),                                                                             // 117
              profile: profile                                                                                   // 118
            });                                                                                                  // 116
            Meteor.users.update({                                                                                // 121
              'services.wechat.openid': resp.openid                                                              // 121
            }, {                                                                                                 // 121
              $set: {                                                                                            // 121
                isWeChat: true                                                                                   // 122
              }                                                                                                  // 121
            });                                                                                                  // 121
            return responseLoginWith(resp.openid);                                                               // 125
          } else {                                                                                               // 126
            return loginFail();                                                                                  // 127
          }                                                                                                      // 128
        });                                                                                                      // 129
      } else {                                                                                                   // 130
        return loginFail();                                                                                      // 131
      }                                                                                                          // 132
    });                                                                                                          // 133
  });                                                                                                            // 135
}                                                                                                                // 136
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"1_startup.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/1_startup.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// Meteor.absoluteUrl.defaultOptions.rootUrl = "http://192.168.0.110:3000"                                       // 1
ROOT_URL = (typeof process !== "undefined" && process !== null ? process.env.ROOT_URL : void 0) || "admin-market.raidcdn.cn";
Meteor.absoluteUrl.defaultOptions.rootUrl = ROOT_URL;                                                            // 3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"2_collections.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/2_collections.js                                                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
//  数据库定义                                                                                                        // 1
function buildRegExp(searchText) {                                                                               // 2
  var words = searchText.trim().split(/[ \-\:]+/);                                                               // 3
                                                                                                                 //
  var exps = _.map(words, function (word) {                                                                      // 4
    return "(?=.*" + word + ")";                                                                                 // 5
  });                                                                                                            // 6
                                                                                                                 //
  var fullExp = exps.join('') + ".+";                                                                            // 7
  return new RegExp(fullExp, "i");                                                                               // 8
} // 产品分类表                                                                                                       // 9
                                                                                                                 //
                                                                                                                 //
Categories = new Mongo.Collection('categories'); // 产品表                                                          // 11
                                                                                                                 //
Products = new Mongo.Collection('products'); // 订单表                                                              // 13
                                                                                                                 //
Orders = new Mongo.Collection('orders'); // 用户购物车                                                                // 15
                                                                                                                 //
Shopping = new Mongo.Collection('shopping'); // 微信token                                                          // 17
                                                                                                                 //
AccessToken = new Mongo.Collection('access_token'); // 用户商品寄送地址信息                                                // 20
                                                                                                                 //
Contact = new Mongo.Collection('contact'); // 分销商销售情况统计                                                          // 23
                                                                                                                 //
SalesOrders = new Mongo.Collection('salesOrders'); // 分销商选中的分销商品列表                                               // 26
                                                                                                                 //
DistributorProducts = new Mongo.Collection('distributorProducts');                                               // 29
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 31
  // search products                                                                                             // 32
  SearchSource.defineSource('products', function (searchText, options) {                                         // 33
    var options = {                                                                                              // 34
      sort: {                                                                                                    // 34
        createdAt: -1                                                                                            // 34
      }                                                                                                          // 34
    };                                                                                                           // 34
                                                                                                                 //
    if (searchText) {                                                                                            // 36
      var regExp = buildRegExp(searchText);                                                                      // 37
      var selector = {                                                                                           // 38
        name: regExp                                                                                             // 38
      };                                                                                                         // 38
      return Products.find(selector, options).fetch();                                                           // 39
    } else {                                                                                                     // 40
      return Products.find({}, options).fetch();                                                                 // 41
    }                                                                                                            // 42
  });                                                                                                            // 43
}                                                                                                                // 44
                                                                                                                 //
if (Meteor.isClient) {                                                                                           // 46
  ProductsSearch = new SearchSource('products', ['name'], {                                                      // 47
    keepHistory: 1000 * 60 * 5,                                                                                  // 48
    localSearch: true                                                                                            // 49
  });                                                                                                            // 47
}                                                                                                                // 51
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"3_publish.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/3_publish.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
if (Meteor.isServer) {                                                                                           // 1
  // 数据发布                                                                                                        // 2
  // 发布分类信息, 按照商家发布                                                                                              // 4
  Meteor.publish("categories_by_seller", function (seller_id) {                                                  // 5
    return Categories.find({                                                                                     // 6
      seller_id: seller_id                                                                                       // 6
    });                                                                                                          // 6
  }); // 发布商品， 按商家发布                                                                                             // 7
                                                                                                                 //
  Meteor.publish("products_by_seller", function (seller_id, limit) {                                             // 11
    var limit = limit || 10;                                                                                     // 12
    return Products.find({                                                                                       // 13
      seller_id: seller_id                                                                                       // 13
    }, {                                                                                                         // 13
      limit: limit                                                                                               // 13
    });                                                                                                          // 13
  }); // 发布商品， 按分销商发布                                                                                            // 14
                                                                                                                 //
  Meteor.publish("products_by_distributor", function (distributor_id, limit) {                                   // 17
    var limit = limit || 10;                                                                                     // 18
    return DistributorProducts.find({                                                                            // 19
      distributor_id: distributor_id                                                                             // 19
    }, {                                                                                                         // 19
      limit: limit                                                                                               // 19
    });                                                                                                          // 19
  }); // 发布商品， 按商家和分类发布                                                                                          // 20
                                                                                                                 //
  Meteor.publish('products_by_category', function (seller_id, category_id, limit, skip) {                        // 22
    var limit = limit || 20;                                                                                     // 23
    var skip = skip || 0;                                                                                        // 24
                                                                                                                 //
    if (!seller_id || !category_id) {                                                                            // 25
      return this.ready();                                                                                       // 26
    }                                                                                                            // 27
                                                                                                                 //
    if (category_id === "all") {                                                                                 // 28
      return Products.find({                                                                                     // 29
        seller_id: seller_id                                                                                     // 29
      }, {                                                                                                       // 29
        limit: limit,                                                                                            // 29
        skip: skip,                                                                                              // 29
        sort: {                                                                                                  // 29
          createdAt: -1                                                                                          // 29
        }                                                                                                        // 29
      });                                                                                                        // 29
    }                                                                                                            // 30
                                                                                                                 //
    return Products.find({                                                                                       // 31
      seller_id: seller_id,                                                                                      // 31
      category_id: category_id                                                                                   // 31
    }, {                                                                                                         // 31
      limit: limit,                                                                                              // 31
      skip: skip,                                                                                                // 31
      sort: {                                                                                                    // 31
        createdAt: -1                                                                                            // 31
      }                                                                                                          // 31
    });                                                                                                          // 31
  }); // 发布商品，按照商品ID发布                                                                                           // 32
                                                                                                                 //
  Meteor.publish('product-by-id', function (_id) {                                                               // 35
    if (!this.userId || !_id) {                                                                                  // 36
      return this.ready();                                                                                       // 37
    }                                                                                                            // 38
                                                                                                                 //
    return [DistributorProducts.find({                                                                           // 39
      product_id: _id,                                                                                           // 40
      distributor_id: this.userId                                                                                // 40
    }), Products.find({                                                                                          // 40
      _id: _id                                                                                                   // 41
    })];                                                                                                         // 41
  });                                                                                                            // 43
  Meteor.publish('userDistributorProductInfo', function (_id) {                                                  // 45
    if (!this.userId || !_id) {                                                                                  // 46
      return this.ready();                                                                                       // 47
    }                                                                                                            // 48
                                                                                                                 //
    return DistributorProducts.find({                                                                            // 49
      product_id: _id,                                                                                           // 49
      distributor_id: this.userId                                                                                // 49
    });                                                                                                          // 49
  });                                                                                                            // 50
  Meteor.publish('distributorProductById', function (_id) {                                                      // 52
    if (!_id) {                                                                                                  // 53
      return this.ready();                                                                                       // 54
    }                                                                                                            // 55
                                                                                                                 //
    return DistributorProducts.find({                                                                            // 56
      _id: _id                                                                                                   // 56
    });                                                                                                          // 56
  }); // 发布订单信息， 按照用户 和 状态发布                                                                                     // 57
                                                                                                                 //
  Meteor.publish('user_orders', function (status, limit) {                                                       // 60
    if (!this.userId || !status) {                                                                               // 61
      return this.ready();                                                                                       // 62
    }                                                                                                            // 63
                                                                                                                 //
    var limit = limit || 10;                                                                                     // 64
    return Orders.find({                                                                                         // 65
      user_id: this.userId,                                                                                      // 65
      status: status                                                                                             // 65
    }, {                                                                                                         // 65
      limit: limit                                                                                               // 65
    });                                                                                                          // 65
  }); // 发布订单信息， 按照商家 和 状态发布                                                                                     // 66
                                                                                                                 //
  Meteor.publish('seller_orders', function (seller_id, status, limit, skip) {                                    // 69
    if (!seller_id || !status) {                                                                                 // 70
      return this.ready();                                                                                       // 71
    }                                                                                                            // 72
                                                                                                                 //
    var limit = limit || 20;                                                                                     // 73
    var skip = skip || 0;                                                                                        // 74
                                                                                                                 //
    if (status == 'all') {                                                                                       // 75
      return Orders.find({                                                                                       // 76
        seller_id: seller_id                                                                                     // 76
      }, {                                                                                                       // 76
        limit: limit,                                                                                            // 76
        skip: skip                                                                                               // 76
      });                                                                                                        // 76
    } else {                                                                                                     // 77
      status = parseInt(status);                                                                                 // 78
      return Orders.find({                                                                                       // 79
        seller_id: seller_id,                                                                                    // 79
        status: status                                                                                           // 79
      }, {                                                                                                       // 79
        limit: limit,                                                                                            // 79
        skip: skip                                                                                               // 79
      });                                                                                                        // 79
    }                                                                                                            // 80
  }); // 发布： 按商品id, 和 user_id                                                                                    // 81
                                                                                                                 //
  Meteor.publish('shopping-by-product-id', function (product_id) {                                               // 84
    if (!this.userId || !product_id) {                                                                           // 85
      return this.ready();                                                                                       // 86
    }                                                                                                            // 87
                                                                                                                 //
    return Shopping.find({                                                                                       // 88
      user_id: this.userId,                                                                                      // 88
      product_id: product_id                                                                                     // 88
    });                                                                                                          // 88
  }); // 发布： 我的购物车                                                                                               // 89
                                                                                                                 //
  Meteor.publish('user_shopping', function (limit) {                                                             // 91
    if (!this.userId) {                                                                                          // 92
      return this.ready();                                                                                       // 93
    }                                                                                                            // 94
                                                                                                                 //
    var limit = limit || 10;                                                                                     // 95
    return Shopping.find({                                                                                       // 96
      user_id: this.userId                                                                                       // 96
    }, {                                                                                                         // 96
      limit: limit,                                                                                              // 96
      sort: {                                                                                                    // 96
        createdAt: -1                                                                                            // 96
      }                                                                                                          // 96
    });                                                                                                          // 96
  }); // 发布订单信息                                                                                                  // 97
                                                                                                                 //
  Meteor.publish('orderInfo', function (_id) {                                                                   // 100
    if (!this.userId || !_id) {                                                                                  // 101
      return this.ready();                                                                                       // 102
    }                                                                                                            // 103
                                                                                                                 //
    return Orders.find({                                                                                         // 104
      _id: _id                                                                                                   // 104
    });                                                                                                          // 104
  }); // 发布用户的订单列表                                                                                               // 105
                                                                                                                 //
  Meteor.publish('user-orders', function () {                                                                    // 108
    if (!this.userId) {                                                                                          // 109
      return this.ready();                                                                                       // 110
    }                                                                                                            // 111
                                                                                                                 //
    return Orders.find({                                                                                         // 112
      user_id: this.userId                                                                                       // 112
    });                                                                                                          // 112
  }); // 发布用户收货地址列表                                                                                              // 113
                                                                                                                 //
  Meteor.publish('contact_list', function () {                                                                   // 116
    if (!this.userId) {                                                                                          // 117
      return this.ready();                                                                                       // 118
    }                                                                                                            // 119
                                                                                                                 //
    return Contact.find({                                                                                        // 120
      user_id: this.userId                                                                                       // 120
    }, {                                                                                                         // 120
      sort: {                                                                                                    // 120
        createdAt: -1                                                                                            // 120
      }                                                                                                          // 120
    });                                                                                                          // 120
  });                                                                                                            // 121
  Meteor.publish('contactInfo', function (_id) {                                                                 // 123
    if (!this.userId || !_id) {                                                                                  // 124
      return this.ready();                                                                                       // 125
    }                                                                                                            // 126
                                                                                                                 //
    return Contact.find({                                                                                        // 127
      _id: _id                                                                                                   // 127
    });                                                                                                          // 127
  }); // 经销商销售情况统计 ，按经销商id                                                                                       // 128
                                                                                                                 //
  Meteor.publish('saleOrders', function () {                                                                     // 131
    if (!this.userId) {                                                                                          // 132
      return this.ready();                                                                                       // 133
    } else {                                                                                                     // 134
      return SalesOrders.find({                                                                                  // 135
        distributor_id: this.userId                                                                              // 135
      });                                                                                                        // 135
    }                                                                                                            // 136
  });                                                                                                            // 137
  Meteor.publish('distributorUserCounts', function () {                                                          // 140
    Counts.publish(this, 'distributorSaleOrderCounts-complate', SalesOrders.find({                               // 141
      'distributor_id': this.userId,                                                                             // 141
      'status': 'complate'                                                                                       // 141
    }));                                                                                                         // 141
    Counts.publish(this, 'distributorSaleOrderCounts-waiting', SalesOrders.find({                                // 142
      'distributor_id': this.userId,                                                                             // 142
      'status': 'waiting'                                                                                        // 142
    }));                                                                                                         // 142
  });                                                                                                            // 143
}                                                                                                                // 144
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"4_allows.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/4_allows.js                                                                                               //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// 创建新订单同时， 创建分销商相应记录                                                                                            // 1
var orderInsertHookHandle = function (doc) {                                                                     // 2
  console.log(JSON.stringify(doc));                                                                              // 3
  Meteor.defer(function () {                                                                                     // 4
    doc.products.forEach(function (item) {                                                                       // 5
      var obj = {                                                                                                // 6
        "order_no": doc.order_no,                                                                                // 7
        // 订单号                                                                                                   // 7
        "product_id": item.product_id,                                                                           // 8
        // 订单商品id                                                                                                // 8
        "product_name": item.product_name,                                                                       // 9
        // 订单商品名称                                                                                                // 9
        "product_img": item.product_img,                                                                         // 10
        // 商家信息                                                                                                  // 11
        "seller_id": item.seller_id,                                                                             // 12
        // 商家 ID                                                                                                 // 12
        "seller_name": item.seller_name,                                                                         // 13
        // 商家名称                                                                                                  // 13
        "seller_icon": item.seller_icon,                                                                         // 14
        // 商家头像                                                                                                  // 14
        // 分销商信息                                                                                                 // 16
        "distributor_id": item.distributor_id,                                                                   // 17
        "distributor_name": item.distributor_name,                                                               // 18
        "distributor_icon": item.distributor_icon,                                                               // 19
        "profit_price": item.profit_price,                                                                       // 21
        // 分销商每销售成功一件可获利金额                                                                                       // 21
        // 订单信息                                                                                                  // 22
        "price": item.product_price,                                                                             // 23
        // 订单单价                                                                                                  // 23
        "product_number": 1,                                                                                     // 24
        // 订单商品数量                                                                                                // 24
        "total_price": doc.total_price,                                                                          // 25
        // 订单总价                                                                                                  // 25
        "createdAt": new Date(),                                                                                 // 26
        // 下单时间                                                                                                  // 26
        "status": 'waiting',                                                                                     // 28
        // 状态： 'complate'(已完成) || 'waiting'(进行中) || 'failed'(用户退款)                                               // 28
        // 下单人信息                                                                                                 // 30
        "user_id": doc.user_id,                                                                                  // 31
        // 下单人id,                                                                                                // 31
        "user_name": doc.user_name,                                                                              // 32
        // 下单人名称                                                                                                 // 32
        "user_icon": doc.user_icon // 下单人ICON                                                                    // 33
                                                                                                                 //
      };                                                                                                         // 6
      SalesOrders.insert(obj);                                                                                   // 35
    });                                                                                                          // 36
  });                                                                                                            // 37
}; // 数据权限                                                                                                       // 38
// 商品分类权限， 只有商家可以修改                                                                                              // 41
                                                                                                                 //
                                                                                                                 //
Categories.allow({                                                                                               // 42
  insert: function (userId, doc) {                                                                               // 43
    // the user must be logged in, and the document must be owned by the user                                    // 44
    return userId && doc.seller_id === userId;                                                                   // 45
  },                                                                                                             // 46
  update: function (userId, doc, fields, modifier) {                                                             // 47
    // can only change your own documents                                                                        // 48
    return doc.seller_id === userId;                                                                             // 49
  },                                                                                                             // 50
  remove: function (userId, doc) {                                                                               // 51
    // can only remove your own documents                                                                        // 52
    return doc.seller_id === userId;                                                                             // 53
  }                                                                                                              // 54
}); // 商品表权限， 只有商家可以修改                                                                                           // 42
                                                                                                                 //
Products.allow({                                                                                                 // 58
  insert: function (userId, doc) {                                                                               // 59
    // the user must be logged in, and the document must be owned by the user                                    // 60
    return userId && doc.seller_id === userId;                                                                   // 61
  },                                                                                                             // 62
  update: function (userId, doc, fields, modifier) {                                                             // 63
    // can only change your own documents                                                                        // 64
    return doc.seller_id === userId;                                                                             // 65
  },                                                                                                             // 66
  remove: function (userId, doc) {                                                                               // 67
    // can only remove your own documents                                                                        // 68
    return doc.seller_id === userId;                                                                             // 69
  }                                                                                                              // 70
}); // 订单表权限， 商家拥有全部权限， 用户只有insert 和 update权限                                                                    // 58
                                                                                                                 //
Orders.allow({                                                                                                   // 75
  insert: function (userId, doc) {                                                                               // 76
    // the user must be logged in, and the document must be owned by the user                                    // 77
    orderInsertHookHandle(doc);                                                                                  // 78
    return true;                                                                                                 // 79
  },                                                                                                             // 80
  update: function (userId, doc, fields, modifier) {                                                             // 81
    // can only change your own documents                                                                        // 82
    return true;                                                                                                 // 83
  },                                                                                                             // 84
  remove: function (userId, doc) {                                                                               // 85
    // can only remove your own documents                                                                        // 86
    return doc.owner === userId;                                                                                 // 87
  }                                                                                                              // 88
});                                                                                                              // 75
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"5_weichat_api.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// lib/5_weichat_api.js                                                                                          //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
// server                                                                                                        // 1
if (Meteor.isServer) {                                                                                           // 2
  var token = '',                                                                                                // 4
      ticket = '',                                                                                               // 4
      appId = 'wxf5fdcd705a634bc9',                                                                              // 4
      appSecret = 'e1d302d0e7f91b7d989eb42ddbc2ab5e';                                                            // 4
                                                                                                                 //
  var jsSHA = Npm.require('jssha');                                                                              // 9
                                                                                                                 //
  var requestUrl = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' + appId + '&secret=' + appSecret; // 随机字符串产生函数
                                                                                                                 //
  var createNonceStr = function () {                                                                             // 13
    return Math.random().toString(36).substr(2, 15);                                                             // 14
  }; // 时间戳产生函数                                                                                                  // 15
                                                                                                                 //
                                                                                                                 //
  var createTimeStamp = function () {                                                                            // 18
    return parseInt(new Date().getTime() / 1000) + '';                                                           // 19
  }; // 计算签名                                                                                                     // 20
                                                                                                                 //
                                                                                                                 //
  var calcSignature = function (ticket, noncestr, ts, url) {                                                     // 23
    var str = 'jsapi_ticket=' + ticket + '&noncestr=' + noncestr + '&timestamp=' + ts + '&url=' + url;           // 24
    var shaObj = new jsSHA('SHA-1', 'TEXT');                                                                     // 25
    shaObj.update(str);                                                                                          // 26
    return shaObj.getHash('HEX');                                                                                // 27
  }; // 获取微信签名所需的 ticket                                                                                         // 28
                                                                                                                 //
                                                                                                                 //
  var generateSignture = function (url) {                                                                        // 31
    var ts = createTimeStamp();                                                                                  // 32
    var nonceStr = createNonceStr();                                                                             // 33
    var signature = calcSignature(ticket, nonceStr, ts, url);                                                    // 34
    console.log('Ticket is ' + ticket + 'Signature is ' + signature);                                            // 35
    var returnSignatures = {                                                                                     // 37
      nonceStr: nonceStr,                                                                                        // 38
      appid: appId,                                                                                              // 39
      timestamp: ts,                                                                                             // 40
      signature: signature,                                                                                      // 41
      url: url                                                                                                   // 42
    };                                                                                                           // 37
    return returnSignatures;                                                                                     // 44
  }; // 获取微信签名所需的 ticket                                                                                         // 45
                                                                                                                 //
                                                                                                                 //
  var updateTicket = function (access_token) {                                                                   // 48
    HTTP.get('https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=' + access_token + '&type=jsapi', function (error, result) {
      if (!error) {                                                                                              // 50
        var resp = result.data;                                                                                  // 51
        ticket = resp.ticket;                                                                                    // 52
        console.log('Ticket is ' + ticket);                                                                      // 53
      }                                                                                                          // 54
    });                                                                                                          // 55
  };                                                                                                             // 56
                                                                                                                 //
  var updateTokenAndTicket = function () {                                                                       // 58
    HTTP.get(requestUrl, function (error, result) {                                                              // 59
      if (!error) {                                                                                              // 60
        console.log('access_token = ' + JSON.stringify(result.data));                                            // 61
        var token = result.data.access_token;                                                                    // 62
        updateTicket(token);                                                                                     // 63
      }                                                                                                          // 64
    });                                                                                                          // 65
  };                                                                                                             // 66
                                                                                                                 //
  updateTokenAndTicket();                                                                                        // 67
  Meteor.setInterval(function () {                                                                               // 68
    updateTokenAndTicket();                                                                                      // 69
  }, 60 * 60 * 1000);                                                                                            // 70
  Router.route('/sign/:url', {                                                                                   // 72
    where: 'server'                                                                                              // 72
  }).get(function () {                                                                                           // 72
    var originalUrl = this.request.originalUrl;                                                                  // 73
    var url = originalUrl.slice(6, originalUrl.length);                                                          // 74
    url = decodeURIComponent(url);                                                                               // 75
    console.log('To sign this url: ' + url);                                                                     // 76
    var result = generateSignture(url);                                                                          // 77
    this.response.end(JSON.stringify(result));                                                                   // 78
  });                                                                                                            // 79
}                                                                                                                // 80
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"method.js":function(){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/method.js                                                                                              //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
Meteor.methods({                                                                                                 // 2
  'getOrderNumber': function () {                                                                                // 3
    var now = new Date();                                                                                        // 4
    var today = new Date();                                                                                      // 5
    today.setUTCHours(0, 0, 0, 0);                                                                               // 6
                                                                                                                 //
    var addZero = function (value) {                                                                             // 7
      if (value < 10) {                                                                                          // 8
        return '0' + value;                                                                                      // 9
      }                                                                                                          // 10
                                                                                                                 //
      return '' + value;                                                                                         // 11
    };                                                                                                           // 12
                                                                                                                 //
    var orderCountToday = Orders.find({                                                                          // 13
      createdAt: {                                                                                               // 13
        $gte: today                                                                                              // 13
      }                                                                                                          // 13
    }).count();                                                                                                  // 13
    orderCountToday += 1;                                                                                        // 15
    var orderNumber = now.getFullYear() + addZero(now.getUTCMonth() + 1) + addZero(now.getUTCDate()) + addZero(now.getUTCHours()) + ("0000000000000000" + orderCountToday).substr(-6);
    return orderNumber;                                                                                          // 17
  },                                                                                                             // 18
  'updateUserRole': function (userId, role) {                                                                    // 19
    Meteor.users.update({                                                                                        // 20
      _id: userId                                                                                                // 20
    }, {                                                                                                         // 20
      $set: {                                                                                                    // 21
        'profile.role': role                                                                                     // 21
      }                                                                                                          // 21
    });                                                                                                          // 20
  }                                                                                                              // 23
});                                                                                                              // 2
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wechat-auth.js":function(require){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/wechat-auth.js                                                                                         //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var OAuth = Npm.require('wechat-oauth');                                                                         // 1
                                                                                                                 //
var client = new OAuth('apppid', 'afd33592eb230c2f8f9936881b2383ba');                                            // 2
var oauthApi = new OAuth('appid', 'sercet', function (openid, callback) {                                        // 4
  Token.getToken(openid, callback);                                                                              // 5
}, function (openid, token, callback) {                                                                          // 6
  Token.setToken(openid, token, callback);                                                                       // 7
});                                                                                                              // 8
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                               //
// server/main.js                                                                                                //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                 //
var Meteor = void 0;                                                                                             // 1
module.watch(require("meteor/meteor"), {                                                                         // 1
  Meteor: function (v) {                                                                                         // 1
    Meteor = v;                                                                                                  // 1
  }                                                                                                              // 1
}, 0);                                                                                                           // 1
Meteor.startup(function () {// code to run on server at startup                                                  // 3
});                                                                                                              // 5
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("./lib/06_router_server.js");
require("./lib/1_startup.js");
require("./lib/2_collections.js");
require("./lib/3_publish.js");
require("./lib/4_allows.js");
require("./lib/5_weichat_api.js");
require("./server/method.js");
require("./server/wechat-auth.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
